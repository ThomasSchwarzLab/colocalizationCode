put the following files in the folders mentioned

folder path:- imageJ> plugins>macros>JanaeColocCode_V4
1.	step1_GetIntensities_.ijm
2.	step2_Quantification_.ijm


folder path:- imageJ>macros>JanaeColocCode_V4
all the rest of the files

Calculations:
> Total cell area without peroxisomes = total cell area (column2) - total peroxisomal area (column7) ---> Value 1

> Total kinesin intensity = total cell area (column2) * mean kinesin intensity (column4) ---> Value 2

> Total kinesin intensity outside peroxisomes = Total kinesin intensity (value 2) - total kinesin intensity on peroxisomes

> Mean kinesin intensity outside of peroxisomes = Total kinesin intensity outside peroxisomes / total cell area without peroxisomes (value 1)

> kinesin enrichment (column 8) = (mean kinesin intensity on peroxisomes - mean kinesin intensity outside peroxisomes)/mean kinesin intensity (column4)
Note: this value should come out to be less than 0 for de-enrichment and more than 0 for enrichment

> kinesin enrichment pex miro normalized (column 9) = kinesin enrichment/total pex-miro on peroxisomes (column 6)

> kinesin enrichment pex miro normalized and gain normalized (column 10) = (kinesin enrichment/kinesin gain) / (total pex-miro on peroxisomes/pex miro gain) (column 6)